$( document ).ready(function() {

    $.getJSON("/mirnafiles", function(data){
         $("#fillME1").html("");
        for(key in data)
            $("#fillME1").append("<option value='"+data [key].value+"'>"+data[key].title+"</option>");
        
   });  


    $.getJSON("/databasefiles", function(data){
         $("#fillME2").html("");
        for(key in data)
            $("#fillME2").append("<option value='"+data [key].value+"'>"+data[key].title+"</option>");
        
   });

   $.getJSON("/fastafiles", function(data){
         $("#FastaInput").html("");
        for(key in data)
            $("#FastaInput").append("<option value='"+data [key].value+"'>"+data[key].title+"</option>");
        
   });      
});


function enableDisableForm(isEnabled, input, type, destenation, button) {
    document.getElementById(input).disabled = !isEnabled;
    document.getElementById(type).disabled = !isEnabled;
    document.getElementById(destenation).disabled = !isEnabled;
    document.getElementById(button).disabled = !isEnabled;
}


 $(document).on("click", "#blast2", function (event) {
        var elem = $(event.currentTarget);
        $("#message").text("Processing...");
    });

$(window).unload( function () 
{
$("#message").text("");
});