#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
'''
Simple web server that demonstrates how browser/server interactions
work for GET and POST requests. Use it as a starting point to create a
custom web server for handling specific requests but don't try to use
it for any production work.

You start by creating a simple index.html file in web directory
somewhere like you home directory: ~/www.

You then add an HTML file: ~/www/index.html. It can be very
simple. Something like this will do nicely:

   <!DOCTYPE html>
   <html>
     <head>
       <meta charset="utf-8">
       <title>WebServer Test</title>
     </head>
     <body>
       <p>Hello, world!</p>
     </body>
   </html>

At this point you have a basic web infrastructure with a single file
so you start the server and point to the ~/www root directory:

   $ webserver.py -r ~/www

This will start the web server listening on your localhost on port
8080. You can change both the host name and the port using the --host
and --port options. See the on-line help for more information (-h,
--help).

If you do not specify a root directory, it will use the directory that
you started the server from.

Now go to your browser and enter http://0.0.0.0:8080 on the command
line and you will see your page.

Try entering http://0.0.0.0:8080/info to see some server information.

You can also use http://127.0.0.1.

By default the server allows you to see directory listings if there is
no index.html or index.htm file. You can disable this by specifying
the --no-dirlist option.

If you want to see a directory listing of a directory that contains a
index.html or index.htm directory, type three trailing backslashes in
the URL like this: http://foo/bar/spam///. This will not work if the
--no-dirlist option is specified.

The default logging level is "info". You can change it using the
"--level" option.

The example below shows how to use a number of the switches to run a
server for host foobar on port 8080 with no directory listing
capability and very little output serving files from ~/www:

  $ hostname
  foobar
  $ webserver --host foobar --port 8080 --level warning --no-dirlist --rootdir ~/www

To daemonize a process, specify the -d or --daemonize option with a
process directory. That directory will contain the log (stdout), err
(stderr) and pid (process id) files for the daemon process. Here is an
example:

  $ hostname
  foobar
  $ webserver --host foobar --port 8080 --level warning --no-dirlist --rootdir ~/www --daemonize ~/www/logs
  $ ls ~/www/logs
  webserver-foobar-8080.err webserver-foobar-8080.log webserver-foobar-8080.pid
'''

# LICENSE
#   Copyright (c) 2015 Joe Linoff
#   
#   Permission is hereby granted, free of charge, to any person obtaining a copy
#   of this software and associated documentation files (the "Software"), to deal
#   in the Software without restriction, including without limitation the rights
#   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#   copies of the Software, and to permit persons to whom the Software is
#   furnished to do so, subject to the following conditions:
#   
#   The above copyright notice and this permission notice shall be included in
#   all copies or substantial portions of the Software.
#   
#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#   THE SOFTWARE.

# VERSIONS
#   1.0  initial release
#   1.1  replace req with self in request handler, add favicon
#   1.2  added directory listings, added --no-dirlist, fixed plain text displays, logging level control, daemonize


'''
A server for Mirna Finder
'''
VERSION = '1.2'

import argparse
import BaseHTTPServer
import cgi
import logging
import os
import sys
import time
import subprocess
import re
import sched, time


def make_request_handler_class(opts):
    '''
    Factory to make the request handler and add arguments to it.

    It exists to allow the handler to access the opts.path variable
    locally.
    '''
    class MyRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
        '''
        Factory generated request handler class that contain
        additional class variables.
        '''
        m_opts = opts

        def do_HEAD(self):
            '''
            Handle a HEAD request.
            '''
            logging.debug('HEADER %s' % (self.path))
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()

        def info(self):
            '''
            Display some useful server information.

            http://127.0.0.1:8080/info
            '''
            self.wfile.write('<html>')
            self.wfile.write('  <head>')
            self.wfile.write('    <title>Server Info</title>')
            self.wfile.write('  </head>')
            self.wfile.write('  <body>')
            self.wfile.write('    <table>')
            self.wfile.write('      <tbody>')
            self.wfile.write('        <tr>')
            self.wfile.write('          <td>client_address</td>')
            self.wfile.write('          <td>%r</td>' % (repr(self.client_address)))
            self.wfile.write('        </tr>')
            self.wfile.write('        <tr>')
            self.wfile.write('          <td>command</td>')
            self.wfile.write('          <td>%r</td>' % (repr(self.command)))
            self.wfile.write('        </tr>')
            self.wfile.write('        <tr>')
            self.wfile.write('          <td>headers</td>')
            self.wfile.write('          <td>%r</td>' % (repr(self.headers)))
            self.wfile.write('        </tr>')
            self.wfile.write('        <tr>')
            self.wfile.write('          <td>path</td>')
            self.wfile.write('          <td>%r</td>' % (repr(self.path)))
            self.wfile.write('        </tr>')
            self.wfile.write('        <tr>')
            self.wfile.write('          <td>server_version</td>')
            self.wfile.write('          <td>%r</td>' % (repr(self.server_version)))
            self.wfile.write('        </tr>')
            self.wfile.write('        <tr>')
            self.wfile.write('          <td>sys_version</td>')
            self.wfile.write('          <td>%r</td>' % (repr(self.sys_version)))
            self.wfile.write('        </tr>')
            self.wfile.write('      </tbody>')
            self.wfile.write('    </table>')
            self.wfile.write('  </body>')
            self.wfile.write('</html>')

        def mirnafiles(self):
            #The Path fot the input for the mirna files
            dirpath = '/Users/Amani/blast/db/practice/mirna-screening/input'
            self.wfile.write('{')
            fnames = ['..']
            fnames.extend(sorted(os.listdir(dirpath), key=str.lower))
            counter=0
            comma="" 
            for fname in fnames:
                if(fname.endswith("fasta") or fname.endswith("fna")):
                    self.wfile.write('%s"%d": {"title":"%s", "value":"%s"}\n' % (comma,counter,fname,fname))
                    comma=","
                    counter=counter+1
            self.wfile.write('}')

        def fastafiles(self):
            #dirpath = os.getcwd()
            #The Path for the fasta files
            dirpath='/Users/Amani/blast/db/practice/mirna-screening/input'
            self.wfile.write('{')
            fnames = ['..']
            fnames.extend(sorted(os.listdir(dirpath), key=str.lower))
            counter=0
            comma="" 
            for fname in fnames:
                if(fname.endswith("fasta") or fname.endswith("fna")):
                    self.wfile.write('%s"%d": {"title":"%s", "value":"%s"}\n' % (comma,counter,fname,fname))
                    comma=","
                    counter=counter+1
            self.wfile.write('}')

        def databasefiles(self):
            #The Path for the Database
            dirpath = '/Users/Amani/blast/db/practice/mirna-screening/input'
            self.wfile.write('{')
            fnames = ['..']
            fnames.extend(sorted(os.listdir(dirpath), key=str.lower))
            counter=0
            comma="" 
            for fname in fnames:
                if(fname.endswith("nin")):
                    dbname=fname.replace(".nin","");
                    self.wfile.write('%s"%d": {"title":"%s", "value":"%s"}\n' % (comma,counter,dbname,dbname))
                    comma=","
                    counter=counter+1
            self.wfile.write('}')

        def resultjson(self):
            '''Processing the result text file  and modify it to be used for the tables'''
            dirpath = '/Users/Amani/blast/db/practice/mirna-screening/'

          
            args = {}
            idx = self.path.find('?')
            if idx >= 0:
                rpath = self.path[:idx]
                args = cgi.parse_qs(self.path[idx+1:])
            else:
                rpath = self.path

            ''' The name of the table (json format)'''
            self.wfile.write('{ "aaData": [\n')
            counter=0
            comma="" 
            ''' creaating a job id for every database or blast result'''

            jobId = str("".join(args['jobid']))
            outputfile=str("".join(args['outputfile']))
            with open('/Users/Amani/blast/db/practice/mirna-screening/jobs/'+str(jobId)+'/'+outputfile, 'r') as f:
                for line in f:
                    fields = line.strip().split()
                    self.wfile.write('    '+ comma +'\n    {\n')
                    self.wfile.write('        "QueryId":"%s",\n' % (fields[0]))
                    self.wfile.write('        "SubjectId":"%s",\n' % (fields[1]))
                    self.wfile.write('        "Identity":"%s",\n' % (fields[2]))
                    self.wfile.write('        "AlignmentLength":"%s",\n' % (fields[3]))
                    self.wfile.write('        "Mismatches":"%s",\n' % (fields[4]))
                    self.wfile.write('        "GapOpen":"%s",\n' % (fields[5]))
                    self.wfile.write('        "QStart":"%s",\n' % (fields[6]))
                    self.wfile.write('        "QEnd":"%s",\n' % (fields[7]))
                    self.wfile.write('        "SStart":"%s",\n' % (fields[8]))
                    self.wfile.write('        "SEnd":"%s",\n' % (fields[9]))
                    self.wfile.write('        "Evalue":"%s",\n' % (fields[10]))
                    self.wfile.write('        "BitScore":"%s",\n' % (fields[11].strip()))
                    self.wfile.write('        "QueryCoverage":"%s"\n' % (fields[12].strip()))
                   
                    self.wfile.write('    }\n')
                    comma=","
                    counter=counter+1
            self.wfile.write(']}\n')


        def do_GET(self):
            '''
            Handle a GET request.
            '''
            logging.debug('GET %s' % (self.path))
            args = {}
            idx = self.path.find('?')
            if idx >= 0:
                rpath = self.path[:idx]
                args = cgi.parse_qs(self.path[idx+1:])
            else:
                rpath = self.path

            if 'content-type' in self.headers:
                ctype, _ = cgi.parse_header(self.headers['content-type'])
                logging.debug('TYPE %s' % (ctype))

            logging.debug('PATH %s' % (rpath))
            logging.debug('ARGS %d' % (len(args)))
            if len(args):
                i = 0
                for key in sorted(args):
                    logging.debug('ARG[%d] %s=%s' % (i, key, args[key]))
                    i += 1

           

            # The files stored internally

            if self.path == '/info' or self.path == '/info/':
                self.send_response(200)  # OK
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.info()
            elif self.path == '/mirnafiles' or self.path == '/mirnafiles/':
                self.send_response(200)  # OK
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.mirnafiles()
            elif self.path == '/databasefiles' or self.path == '/databasefiles/':
                self.send_response(200)  # OK
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.databasefiles()

            elif self.path.startswith('/resultjson'):
                self.send_response(200)  # OK
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.resultjson()

            elif self.path == '/fastafiles' or self.path == '/fastafiles/':
                self.send_response(200)  # OK
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.fastafiles()

            else:
                # Get the file path.
                path = MyRequestHandler.m_opts.rootdir + rpath
                dirpath = None
                logging.debug('FILE %s' % (path))

                # If it is a directory look for index.html
                # or process it directly if there are 3
                # trailing slashed.
                if rpath[-3:] == '///':
                    dirpath = path
                elif os.path.exists(path) and os.path.isdir(path):
                    dirpath = path  # the directory portion
                    index_files = ['/index.html', '/index.htm', ]
                    for index_file in index_files:
                        tmppath = path + index_file
                        if os.path.exists(tmppath):
                            path = tmppath
                            break

                # Allow the user to type "///" at the end to see the
                # directory listing.
                if os.path.exists(path) and os.path.isfile(path):
                    # This is valid file, send it as the response
                    # after determining whether it is a type that
                    # the server recognizes.
                    _, ext = os.path.splitext(path)
                    ext = ext.lower()
                    content_type = {
                        '.css': 'text/css',
                        '.gif': 'image/gif',
                        '.htm': 'text/html',
                        '.html': 'text/html',
                        '.jpeg': 'image/jpeg',
                        '.jpg': 'image/jpg',
                        '.js': 'text/javascript',
                        '.png': 'image/png',
                        '.text': 'text/plain',
                        '.txt': 'text/plain',
                    }

                    # If it is a known extension, set the correct
                    # content type in the response.
                    if ext in content_type:
                        self.send_response(200)  # OK
                        self.send_header('Content-type', content_type[ext])
                        self.end_headers()

                        with open(path) as ifp:
                            self.wfile.write(ifp.read())
                    else:
                        # Unknown file type or a directory.
                        # Treat it as plain text.
                        self.send_response(200)  # OK
                        self.send_header('Content-type', 'text/plain')
                        self.end_headers()

                        with open(path) as ifp:
                            self.wfile.write(ifp.read())
                else:
                    if dirpath is None or self.m_opts.no_dirlist == True:
                        # Invalid file path, respond with a server access error
                        self.send_response(500)  # generic server error for now
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()

                        self.wfile.write('<html>')
                        self.wfile.write('  <head>')
                        self.wfile.write('    <title>Server Access Error</title>')
                        self.wfile.write('  </head>')
                        self.wfile.write('  <body>')
                        self.wfile.write('    <p>Server access error.</p>')
                        self.wfile.write('    <p>%r</p>' % (repr(self.path)))
                        self.wfile.write('    <p><a href="%s">Back</a></p>' % (rpath))
                        self.wfile.write('  </body>')
                        self.wfile.write('</html>')
                    else:
                        # List the directory contents. Allow simple navigation.
                        logging.debug('DIR %s' % (dirpath))

                        self.send_response(200)  # OK
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        
                        self.wfile.write('<html>')
                        self.wfile.write('  <head>')
                        self.wfile.write('    <title>%s</title>' % (dirpath))
                        self.wfile.write('  </head>')
                        self.wfile.write('  <body>')
                        self.wfile.write('    <a href="%s">Home</a><br>' % ('/'));

                        # Make the directory path navigable.
                        dirstr = ''
                        href = None
                        for seg in rpath.split('/'):
                            if href is None:
                                href = seg
                            else:
                                href = href + '/' + seg
                                dirstr += '/'
                            dirstr += '<a href="%s">%s</a>' % (href, seg)
                        self.wfile.write('    <p>Directory: %s</p>' % (dirstr))

                        # Write out the simple directory list (name and size).
                        self.wfile.write('    <table border="0">')
                        self.wfile.write('      <tbody>')
                        fnames = ['..']
                        fnames.extend(sorted(os.listdir(dirpath), key=str.lower))
                        for fname in fnames:
                            self.wfile.write('        <tr>')
                            self.wfile.write('          <td align="left">')
                            path = rpath + '/' + fname
                            fpath = os.path.join(dirpath, fname)
                            if os.path.isdir(path):
                                self.wfile.write('            <a href="%s">%s/</a>' % (path, fname))
                            else:
                                self.wfile.write('            <a href="%s">%s</a>' % (path, fname))
                            self.wfile.write('          <td>&nbsp;&nbsp;</td>')
                            self.wfile.write('          </td>')
                            self.wfile.write('          <td align="right">%d</td>' % (os.path.getsize(fpath)))
                            self.wfile.write('        </tr>')
                        self.wfile.write('      </tbody>')
                        self.wfile.write('    </table>')
                        self.wfile.write('  </body>')
                        self.wfile.write('</html>')

        

        def do_POST(self):
            '''
            Handle POST requests.
            '''
            jobId= int(time.time())
            os.mkdir('jobs/'+str(jobId))
            logging.debug('POST %s' % (self.path))

            # CITATION: http://stackoverflow.com/questions/4233218/python-basehttprequesthandler-post-variables
            ctype, pdict = cgi.parse_header(self.headers['content-type'])
            if ctype == 'multipart/form-data':
                postvars = cgi.parse_multipart(self.rfile, pdict)
            elif ctype == 'application/x-www-form-urlencoded':
                length = int(self.headers['content-length'])
                postvars = cgi.parse_qs(self.rfile.read(length), keep_blank_values=1)
            else:
                postvars = {}

            # Get the "Back" link.
            back = self.path if self.path.find('?') < 0 else self.path[:self.path.find('?')]

            # Print out logging information about the path and args.
            logging.debug('TYPE %s' % (ctype))
            logging.debug('PATH %s' % (self.path))
            logging.debug('ARGS %d' % (len(postvars)))
            if len(postvars):
                i = 0
                for key in sorted(postvars):
                    logging.debug('ARG[%d] %s=%s' % (i, key, postvars[key]))
                    i += 1

            # Tell the browser everything is okay and that there is
            # HTML to display.
            self.send_response(200)  # OK
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            ''' The buttons for the forms'''
            post_submit=str("".join(postvars['submit']))
            if (post_submit== 'POST Blast1'):
                self.NewDBPage(postvars,jobId)
            else:
                self.resultPage(postvars,jobId)
        
        def NewDBPage(self,postvars,jobId):
            '''creating the database'''
         
            if len(postvars):
                i = 0
                for key in sorted(postvars):
                    i += 1
                    val = postvars[key]
                  
                self.wfile.write(' <script type="text/javascript">window.location = "/webserver.html";</script>')

                path=str("".join(postvars['post_arg4']))
                dbtype=str("".join(postvars['post_arg5']))
                post_arg6=str("".join(postvars['post_arg6']))

                # making the database command
            outputfile= post_arg6
            database_command =('makeblastdb -in input/'+str(path) + ' -dbtype ' + dbtype + ' -out jobs/'+str(jobId)+'/' + outputfile )
            os.system(database_command)
            
        
        def resultPage(self,postvars,jobId):
            # the heades for the result table  
            # Display the POST variables.
            self.wfile.write('<html>')
            self.wfile.write('  <head>')
            self.wfile.write('    <title>Results</title>')
            self.wfile.write('<meta charset=utf-8 />')
            self.wfile.write('<title>Yet Another DataTables Column Filter (yadcf) Showcase</title>')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/chosen.min.css" rel="stylesheet" type="text/css" />')
    
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/jquery.dataTables.10.min.css" rel="stylesheet" type="text/css"></link>')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/dataTables.colVis.css" rel="stylesheet" type="text/css"></link>')
            self.wfile.write('<link href="dataTables.jqueryui.css" rel="stylesheet" type="text/css"></link>')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/dataTables.responsive.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/jquery-ui.1.9.0.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/fixedHeader.dataTables.min.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/jquery.dataTables.yadcf.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/shCore.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/shThemeDefault.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="http://yadcf-showcase.appspot.com/resources/css/main.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<link href="site.css" rel="stylesheet" type="text/css" />')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/jquery-1.8.2.min.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/jquery-ui.1.9.0.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/chosen.jquery.min.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/jquery.dataTables.10.min.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/dataTables.fixedHeader.min.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/dataTables.responsive.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/dataTables.jqueryui.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/dataTables.colVis.js"></script>')
            self.wfile.write('<script src="http://yadcf-showcase.appspot.com/resources/js/jquery.dataTables.yadcf.js"></script>')
            self.wfile.write('<script type="text/javascript" src="http://yadcf-showcase.appspot.com/resources/js/shCore.js"></script>')
            self.wfile.write('<script type="text/javascript" src="http://yadcf-showcase.appspot.com/resources/js/shBrushJScript.js"></script>')
            self.wfile.write(' <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">')
            self.wfile.write('  <style> .resultHead{ font-size:small;}</style></head>')
            self.wfile.write('  <body> <br/> <div class="container"> <div class="panel panel-default">')
            self.wfile.write(' <div class="panel-heading" style="text-align:center; text-size:large;"><b>  Results <b></div>')
            
            if len(postvars):
               
                self.wfile.write('<div class="panel-body">')
                i = 0
                for key in sorted(postvars):
                    i += 1
                    val = postvars[key]
                    
                    # the arguments for the command line
                post_arg1=str("".join(postvars['post_arg1']))
                post_arg2=str("".join(postvars['post_arg2']))
                post_arg3=str("".join(postvars['post_arg3']))

            outputfile= post_arg3+".txt"
            #blast command
            
            blast_command = ('blastn -task blastn-short  -query input/'+str(post_arg1)+' -db input/' +str(post_arg2)+ ' -out  jobs/'+str(jobId) +'/' +outputfile +' -num_threads 8 -outfmt "6 std qcovs" ')
            
            #self.wfile.write("<br><pre>*****" +blast_command+"*******</pre>\n")
            os.system(blast_command)
            #s = sched.scheduler(time.time, time.sleep)
            #s.enter(60, 1, os.system(restarter.py), (sc,))
            self.table(jobId,outputfile)





        def jsontable(self, jobId,outputfile):
            #the result table Json
            self.wfile.write('<script>')
            self.wfile.write('var jobId="'+str(jobId)+'";')
            self.wfile.write('var outputfile="'+str(outputfile)+'";')
            self.wfile.write('</script>')
            self.wfile.write('<script src="site2.js"></script>')
            self.wfile.write('<div id="table_2">')
            self.wfile.write('<table cellpadding="10" cellspacing="30" border="1" class="display" id="entrys_table" >')
            self.wfile.write('<thead>')
            self.wfile.write('<tr>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">Query Id</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">Subject Id</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">Identity</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">Alignment Length</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">Mismatches</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">GapOpen</th>')
            self.wfile.write('<th width="250px" style="padding-left: 25px; padding-right: 25px">QStart</th>')
            self.wfile.write('<th width="250px" style="padding-left: 25px; padding-right: 25px">QEnd</th>')
            self.wfile.write('<th width="250px" style="padding-left: 25px; padding-right: 25px">SStart</th>')
            self.wfile.write('<th width="250px" style="padding-left: 25px; padding-right: 25px">SEnd</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">Evalue</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">BitScore</th>')
            self.wfile.write('<th width="150px" style="padding-left: 25px; padding-right: 25px">QueryCoverage</th>')
            self.wfile.write('</tr>')
            self.wfile.write('</thead>')
            self.wfile.write('<tbody>')
            self.wfile.write('</tbody>')
            self.wfile.write('</table>')
            self.wfile.write('</div>')



        def table(self, jobId , outputfile ):
         # Closing the html page
            self.wfile.write(' </div> </div>')
            self.jsontable(jobId,outputfile)  
            self.wfile.write('<p><center><a class="btn btn-default role="button" href="%s">Back</a></center></p>' % (back))
            self.wfile.write('</body>')
            self.wfile.write('</html>')

    return MyRequestHandler



def err(msg):
    '''
    Report an error message and exit.
    '''
    print('ERROR: %s' % (msg))
    sys.exit(1)


def getopts():
    '''
    Get the command line options.
    '''

    # Get the help from the module documentation.
    this = os.path.basename(sys.argv[0])
    description = ('description:%s' % '\n  '.join(__doc__.split('\n')))
    epilog = ' '
    rawd = argparse.RawDescriptionHelpFormatter
    parser = argparse.ArgumentParser(formatter_class=rawd,
                                     description=description,
                                     epilog=epilog)

    parser.add_argument('-d', '--daemonize',
                        action='store',
                        type=str,
                        default='.',
                        metavar='DIR',
                        help='daemonize this process, store the 3 run files (.log, .err, .pid) in DIR (default "%(default)s")')

    parser.add_argument('-H', '--host',
                        action='store',
                        type=str,
                        default='localhost',
                        help='hostname, default=%(default)s')

    parser.add_argument('-l', '--level',
                        action='store',
                        type=str,
                        default='info',
                        choices=['notset', 'debug', 'info', 'warning', 'error', 'critical',],
                        help='define the logging level, the default is %(default)s')

    parser.add_argument('--no-dirlist',
                        action='store_true',
                        help='disable directory listings')

    parser.add_argument('-p', '--port',
                        action='store',
                        type=int,
                        default=8080,
                        help='port, default=%(default)s')

    parser.add_argument('-r', '--rootdir',
                        action='store',
                        type=str,
                        default=os.path.abspath('.'),
                        help='web directory root that contains the HTML/CSS/JS files %(default)s')

    parser.add_argument('-v', '--verbose',
                        action='count',
                        help='level of verbosity')

    parser.add_argument('-V', '--version',
                        action='version',
                        version='%(prog)s - v' + VERSION)

    opts = parser.parse_args()
    opts.rootdir = os.path.abspath(opts.rootdir)
    if not os.path.isdir(opts.rootdir):
        err('Root directory does not exist: ' + opts.rootdir)
    if opts.port < 1 or opts.port > 65535:
        err('Port is out of range [1..65535]: %d' % (opts.port))
    return opts


def httpd(opts):
    '''
    HTTP server
    '''
    RequestHandlerClass = make_request_handler_class(opts)
    server = BaseHTTPServer.HTTPServer((opts.host, opts.port), RequestHandlerClass)
    logging.info('Server starting %s:%s (level=%s)' % (opts.host, opts.port, opts.level))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    logging.info('Server stopping %s:%s' % (opts.host, opts.port))


def get_logging_level(opts):
    '''
    Get the logging levels specified on the command line.
    The level can only be set once.
    '''
    if opts.level == 'notset':
        return logging.NOTSET
    elif opts.level == 'debug':
        return logging.DEBUG
    elif opts.level == 'info':
        return logging.INFO
    elif opts.level == 'warning':
        return logging.WARNING
    elif opts.level == 'error':
        return logging.ERROR
    elif opts.level == 'critical':
        return logging.CRITICAL


def daemonize(opts):
    '''
    Daemonize this process.

    CITATION: http://stackoverflow.com/questions/115974/what-would-be-the-simplest-way-to-daemonize-a-python-script-in-linux
    '''
    if os.path.exists(opts.daemonize) is False:
        err('directory does not exist: ' + opts.daemonize)

    if os.path.isdir(opts.daemonize) is False:
        err('not a directory: ' + opts.daemonize)

    bname = 'webserver-%s-%d' % (opts.host, opts.port)
    outfile = os.path.abspath(os.path.join(opts.daemonize, bname + '.log'))
    errfile = os.path.abspath(os.path.join(opts.daemonize, bname + '.err'))
    pidfile = os.path.abspath(os.path.join(opts.daemonize, bname + '.pid'))

    if os.path.exists(pidfile):
        err('pid file exists, cannot continue: ' + pidfile)
    if os.path.exists(outfile):
        os.unlink(outfile)
    if os.path.exists(errfile):
        os.unlink(errfile)

    if os.fork():
        sys.exit(0)  # exit the parent

    os.umask(0)
    os.setsid()
    if os.fork():
        sys.exit(0)  # exit the parent

    print('daemon pid %d' % (os.getpid()))

    sys.stdout.flush()
    sys.stderr.flush()

    stdin = file('/dev/null', 'r')
    stdout = file(outfile, 'a+')
    stderr = file(errfile, 'a+', 0)

    os.dup2(stdin.fileno(), sys.stdin.fileno())
    os.dup2(stdout.fileno(), sys.stdout.fileno())
    os.dup2(stderr.fileno(), sys.stderr.fileno())

    with open(pidfile, 'w') as ofp:
        ofp.write('%i' % (os.getpid()))


def main():
    ''' main entry '''
    opts = getopts()
    if opts.daemonize:
        daemonize(opts)
    logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', level=get_logging_level(opts))
    httpd(opts)


if __name__ == '__main__':
    main()  # this allows library functionality
