/*global $, SyntaxHighlighter*/


var oTable2;

$(document).ready(function () {
    'use strict';

   

    oTable2 = $('#entrys_table').DataTable({
    	//"responsive": true,
        "processing": true,
        "ajax": "resultjson?jobid="+jobId+"&outputfile="+outputfile,
       // "sDom": 't',


        "columns":
        [
            {"data": "QueryId"},
            {"data": "SubjectId"},  
            {"data": "Identity"},
            {"data": "AlignmentLength"},
            {"data": "Mismatches"},
            {"data": "GapOpen"},
            {"data": "QStart"},  
            {"data": "QEnd"},
            {"data": "SStart"},
            {"data": "SEnd"},
            {"data": "Evalue"},
            {"data": "BitScore"},
            {"data": "QueryCoverage"}
        ]
    });

    yadcf.init(oTable2, [

    {column_number: 0},
    {column_number: 1},
    {column_number: 2},
    {column_number: 3},
    {column_number: 4},
    {column_number: 5},
    {
        column_number: 6,
        filter_type: "range_number_slider",
        ignore_char: "-"
    },
    {
        column_number: 7,
        filter_type: "range_number_slider",
        ignore_char: "-"
    },
    {column_number: 8,
        filter_type: "range_number_slider",
        ignore_char: "-"
    },
    {column_number: 9,
    filter_type: "range_number_slider",
        ignore_char: "-"},
    {column_number: 10},
    {column_number: 11},
     {column_number: 12}
    ]);
    
    function showpanel() {     
    
    $( "#entrys_table" ).wrap( "<div class='outter'></div>" );
    $( "#entrys_table" ).wrap( "<div class='inner'></div>" );
  
 }

 // use setTimeout() to execute
 setTimeout(showpanel, 1000)

   
	
	
	yadcf.initMultipleTables([oTable, oTable2], [{
		filter_container_id: 'multi-table-filter', filter_default_label: 'Filter all tables!'
	}]);
    SyntaxHighlighter.all();



});