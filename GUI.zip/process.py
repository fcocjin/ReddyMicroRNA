#!/Library/Frameworks/Python.framework/Versions/2.7/bin/python

import os

process_name= "blastn" 

tmp = os.popen("ps -Af").read()

if process_name in tmp[:]:
    print "The process is running."
